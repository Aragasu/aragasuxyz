Game1 is Astra Client (eaglercraft) which is a website and doesn't need any files

additional files:
  _jxstShadow-ASTRACLIENT-backup.epk