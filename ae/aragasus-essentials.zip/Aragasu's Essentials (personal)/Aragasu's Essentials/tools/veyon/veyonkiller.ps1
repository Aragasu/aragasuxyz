Get-Process | Where-Object { $_.ProcessName -match "veyon" } | Stop-Process -Force
Write-Host "done"